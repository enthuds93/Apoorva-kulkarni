use supply_db ;

/*
Question : Golf related products

List all products in categories related to golf. Display the Product_Id, Product_Name in the output. Sort the output in the order of product id.
Hint: You can identify a Golf category by the name of the category that contains golf.

*/

select  Product_Id, Product_Name
from product_info p 
left join category c on p.Category_Id = c.Id
where lower(Name) like "%golf%"
order by Product_Id;


-- **********************************************************************************************************************************

/*
Question : Most sold golf products

Find the top 10 most sold products (based on sales) in categories related to golf. Display the Product_Name and Sales column in the output. Sort the output in the descending order of sales.
Hint: You can identify a Golf category by the name of the category that contains golf.

HINT:
Use orders, ordered_items, product_info, and category tables from the Supply chain dataset.
*/

with product_sales as
(
select Product_Name, 
	   sum(Sales) as sales,
       rank() over(order by sum(Sales) desc) as sales_rank
from category as cat
left join product_info as prod_info
on cat.Id = prod_info.Category_Id
left join ordered_items as ord_itm
on prod_info.Product_Id = ord_itm.Item_Id
where lower(Name) like "%golf%"
group by Product_Name
order by sales desc
)
select Product_Name, sales
from product_sales
where sales_rank <= 10;

-- **********************************************************************************************************************************

/*
Question: Segment wise orders

Find the number of orders by each customer segment for orders. Sort the result from the highest to the lowest 
number of orders.The output table should have the following information:
-Customer_segment
-Orders
*/
select Segment as Customer_segment, count(Order_Id) as Orders
from customer_info cust
left join orders ord on cust.Id = ord.Customer_Id
group by Segment
order by Orders desc;
-- **********************************************************************************************************************************
/*
Question : Percentage of order split

Description: Find the percentage of split of orders by each customer segment for orders that took six days 
to ship (based on Real_Shipping_Days). Sort the result from the highest to the lowest percentage of split orders,
rounding off to one decimal place. The output table should have the following information:
-Customer_segment
-Percentage_order_split
HINT:
Use the orders and customer_info tables from the Supply chain dataset.
*/

-- CTE containing segment wise order count
with segment_orders as
(
select Segment as Customer_segment, count(Order_Id) as Orders
from customer_info cust
left join orders ord on cust.Id = ord.Customer_Id
where Real_Shipping_Days = 6
group by Segment
)
select a.Customer_segment, round(a.Orders/sum(b.Orders)*100, 1) as Percentage_order_split
from segment_orders a 
join segment_orders b 
group by a.Customer_segment
order by Percentage_order_split desc;

-- **********************************************************************************************************************************